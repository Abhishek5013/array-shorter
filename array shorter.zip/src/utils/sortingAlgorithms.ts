
import { sleep } from './arrayHelpers';

export type SortingAlgorithm = {
  name: string;
  description: string;
  timeComplexity: string;
  spaceComplexity: string;
  worstCase: string;
  bestCase: string;
  sort: (
    array: number[], 
    updateArray: (newArray: number[]) => void, 
    updateIndices: (indices: number[]) => void,
    delay: number
  ) => Promise<void>;
};

export type ArrayState = {
  array: number[];
  comparingIndices: number[];
  sortedIndices: number[];
  selectedIndex: number;
};

/**
 * Bubble Sort Algorithm
 */
export const bubbleSort: SortingAlgorithm = {
  name: "Bubble Sort",
  description: "A simple comparison-based sorting algorithm that repeatedly steps through the list, compares adjacent elements, and swaps them if they are in the wrong order.",
  timeComplexity: "O(n²)",
  spaceComplexity: "O(1)",
  worstCase: "O(n²)",
  bestCase: "O(n)",
  sort: async (array, updateArray, updateIndices, delay) => {
    const arr = [...array];
    const n = arr.length;
    let sorted = false;
    
    for (let i = 0; i < n - 1; i++) {
      sorted = true;
      
      for (let j = 0; j < n - i - 1; j++) {
        updateIndices([j, j + 1]);
        await sleep(delay);
        
        if (arr[j] > arr[j + 1]) {
          [arr[j], arr[j + 1]] = [arr[j + 1], arr[j]];
          updateArray([...arr]);
          sorted = false;
        }
      }
      
      if (sorted) break;
    }
    
    updateIndices([]);
    return;
  }
};

/**
 * Selection Sort Algorithm
 */
export const selectionSort: SortingAlgorithm = {
  name: "Selection Sort",
  description: "A simple in-place comparison sorting algorithm that divides the input into a sorted and an unsorted region, and repeatedly selects the smallest element from the unsorted region and moves it to the sorted region.",
  timeComplexity: "O(n²)",
  spaceComplexity: "O(1)",
  worstCase: "O(n²)",
  bestCase: "O(n²)",
  sort: async (array, updateArray, updateIndices, delay) => {
    const arr = [...array];
    const n = arr.length;
    
    for (let i = 0; i < n - 1; i++) {
      let minIdx = i;
      
      for (let j = i + 1; j < n; j++) {
        updateIndices([minIdx, j]);
        await sleep(delay);
        
        if (arr[j] < arr[minIdx]) {
          minIdx = j;
        }
      }
      
      if (minIdx !== i) {
        [arr[i], arr[minIdx]] = [arr[minIdx], arr[i]];
        updateArray([...arr]);
      }
    }
    
    updateIndices([]);
    return;
  }
};

/**
 * Insertion Sort Algorithm
 */
export const insertionSort: SortingAlgorithm = {
  name: "Insertion Sort",
  description: "A simple sorting algorithm that builds the final sorted array one item at a time, by repeatedly taking the next element and inserting it into its correct position in the sorted part of the array.",
  timeComplexity: "O(n²)",
  spaceComplexity: "O(1)",
  worstCase: "O(n²)",
  bestCase: "O(n)",
  sort: async (array, updateArray, updateIndices, delay) => {
    const arr = [...array];
    const n = arr.length;
    
    for (let i = 1; i < n; i++) {
      const key = arr[i];
      let j = i - 1;
      
      while (j >= 0 && arr[j] > key) {
        updateIndices([j, j + 1]);
        await sleep(delay);
        
        arr[j + 1] = arr[j];
        updateArray([...arr]);
        j--;
      }
      
      arr[j + 1] = key;
      updateArray([...arr]);
    }
    
    updateIndices([]);
    return;
  }
};

/**
 * Merge Sort Algorithm
 */
export const mergeSort: SortingAlgorithm = {
  name: "Merge Sort",
  description: "An efficient, stable, comparison-based, divide and conquer sorting algorithm that divides the input array into two halves, recursively sorts them, and then merges the sorted halves.",
  timeComplexity: "O(n log n)",
  spaceComplexity: "O(n)",
  worstCase: "O(n log n)",
  bestCase: "O(n log n)",
  sort: async (array, updateArray, updateIndices, delay) => {
    const arr = [...array];
    
    const merge = async (left: number, mid: number, right: number) => {
      const n1 = mid - left + 1;
      const n2 = right - mid;
      
      const L = arr.slice(left, left + n1);
      const R = arr.slice(mid + 1, mid + 1 + n2);
      
      let i = 0, j = 0, k = left;
      
      while (i < n1 && j < n2) {
        updateIndices([left + i, mid + 1 + j]);
        await sleep(delay);
        
        if (L[i] <= R[j]) {
          arr[k] = L[i];
          i++;
        } else {
          arr[k] = R[j];
          j++;
        }
        
        updateArray([...arr]);
        k++;
      }
      
      while (i < n1) {
        updateIndices([k]);
        await sleep(delay / 2);
        
        arr[k] = L[i];
        updateArray([...arr]);
        i++;
        k++;
      }
      
      while (j < n2) {
        updateIndices([k]);
        await sleep(delay / 2);
        
        arr[k] = R[j];
        updateArray([...arr]);
        j++;
        k++;
      }
    };
    
    const mergeSortRecursive = async (left: number, right: number) => {
      if (left < right) {
        const mid = Math.floor(left + (right - left) / 2);
        
        await mergeSortRecursive(left, mid);
        await mergeSortRecursive(mid + 1, right);
        
        await merge(left, mid, right);
      }
    };
    
    await mergeSortRecursive(0, arr.length - 1);
    updateIndices([]);
    return;
  }
};

/**
 * Quick Sort Algorithm
 */
export const quickSort: SortingAlgorithm = {
  name: "Quick Sort",
  description: "An efficient, in-place sorting algorithm that uses a divide-and-conquer strategy, selecting a 'pivot' element and partitioning the array around it.",
  timeComplexity: "O(n log n)",
  spaceComplexity: "O(log n)",
  worstCase: "O(n²)",
  bestCase: "O(n log n)",
  sort: async (array, updateArray, updateIndices, delay) => {
    const arr = [...array];
    
    const partition = async (low: number, high: number) => {
      const pivot = arr[high];
      let i = low - 1;
      
      for (let j = low; j < high; j++) {
        updateIndices([j, high]);
        await sleep(delay);
        
        if (arr[j] < pivot) {
          i++;
          [arr[i], arr[j]] = [arr[j], arr[i]];
          updateArray([...arr]);
        }
      }
      
      [arr[i + 1], arr[high]] = [arr[high], arr[i + 1]];
      updateArray([...arr]);
      
      return i + 1;
    };
    
    const quickSortRecursive = async (low: number, high: number) => {
      if (low < high) {
        const pi = await partition(low, high);
        
        await quickSortRecursive(low, pi - 1);
        await quickSortRecursive(pi + 1, high);
      }
    };
    
    await quickSortRecursive(0, arr.length - 1);
    updateIndices([]);
    return;
  }
};

/**
 * Heap Sort Algorithm
 */
export const heapSort: SortingAlgorithm = {
  name: "Heap Sort",
  description: "A comparison-based sorting algorithm that uses a binary heap data structure to build a max-heap and repeatedly extracts the maximum element.",
  timeComplexity: "O(n log n)",
  spaceComplexity: "O(1)",
  worstCase: "O(n log n)",
  bestCase: "O(n log n)",
  sort: async (array, updateArray, updateIndices, delay) => {
    const arr = [...array];
    const n = arr.length;
    
    const heapify = async (n: number, i: number) => {
      let largest = i;
      const left = 2 * i + 1;
      const right = 2 * i + 2;
      
      if (left < n) {
        updateIndices([largest, left]);
        await sleep(delay);
        
        if (arr[left] > arr[largest]) {
          largest = left;
        }
      }
      
      if (right < n) {
        updateIndices([largest, right]);
        await sleep(delay);
        
        if (arr[right] > arr[largest]) {
          largest = right;
        }
      }
      
      if (largest !== i) {
        [arr[i], arr[largest]] = [arr[largest], arr[i]];
        updateArray([...arr]);
        
        await heapify(n, largest);
      }
    };
    
    for (let i = Math.floor(n / 2) - 1; i >= 0; i--) {
      await heapify(n, i);
    }
    
    for (let i = n - 1; i > 0; i--) {
      updateIndices([0, i]);
      await sleep(delay);
      
      [arr[0], arr[i]] = [arr[i], arr[0]];
      updateArray([...arr]);
      
      await heapify(i, 0);
    }
    
    updateIndices([]);
    return;
  }
};

export const sortingAlgorithms: SortingAlgorithm[] = [
  bubbleSort,
  selectionSort,
  insertionSort,
  mergeSort,
  quickSort,
  heapSort
];
