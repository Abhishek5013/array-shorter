
/**
 * Generate a random array of integers
 */
export function generateRandomArray(size: number, min: number = 5, max: number = 100): number[] {
  return Array.from({ length: size }, () => Math.floor(Math.random() * (max - min + 1)) + min);
}

/**
 * Generate a nearly sorted array (some elements out of place)
 */
export function generateNearlySortedArray(size: number, min: number = 5, max: number = 100, swapCount: number = 5): number[] {
  // Create sorted array
  const array = Array.from({ length: size }, (_, i) => Math.floor((i / size) * (max - min) + min));
  
  // Perform a few random swaps
  for (let i = 0; i < swapCount; i++) {
    const idx1 = Math.floor(Math.random() * size);
    const idx2 = Math.floor(Math.random() * size);
    [array[idx1], array[idx2]] = [array[idx2], array[idx1]];
  }
  
  return array;
}

/**
 * Generate a reversed array
 */
export function generateReversedArray(size: number, min: number = 5, max: number = 100): number[] {
  return Array.from({ length: size }, (_, i) => Math.floor(((size - i - 1) / size) * (max - min) + min));
}

/**
 * Delay execution for animation purposes
 */
export function sleep(ms: number): Promise<void> {
  return new Promise(resolve => setTimeout(resolve, ms));
}

/**
 * Find the maximum value in an array
 */
export function findMaxValue(array: number[]): number {
  return Math.max(...array);
}

/**
 * Calculate execution time for an algorithm
 */
export async function measureExecutionTime<T>(fn: () => Promise<T>): Promise<[T, number]> {
  const start = performance.now();
  const result = await fn();
  const end = performance.now();
  return [result, end - start];
}
