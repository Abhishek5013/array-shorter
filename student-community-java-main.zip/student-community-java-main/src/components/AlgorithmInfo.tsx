
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { SortingAlgorithm } from '@/utils/sortingAlgorithms';

interface AlgorithmInfoProps {
  algorithm: SortingAlgorithm;
  comparisons?: number;
  swaps?: number;
  elapsedTime?: number;
}

const AlgorithmInfo = ({
  algorithm,
  comparisons = 0,
  swaps = 0,
  elapsedTime = 0,
}: AlgorithmInfoProps) => {
  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex justify-between items-center">
          <span>{algorithm.name}</span>
          <Badge variant="outline">{algorithm.timeComplexity}</Badge>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <p className="text-sm text-muted-foreground">{algorithm.description}</p>
            
            <div className="flex flex-col gap-1">
              <div className="flex justify-between text-sm">
                <span className="font-medium">Time Complexity:</span>
                <span>{algorithm.timeComplexity}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="font-medium">Space Complexity:</span>
                <span>{algorithm.spaceComplexity}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="font-medium">Best Case:</span>
                <span>{algorithm.bestCase}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="font-medium">Worst Case:</span>
                <span>{algorithm.worstCase}</span>
              </div>
            </div>
          </div>
          
          <div className="space-y-3">
            <h4 className="text-sm font-medium">Current Execution Stats</h4>
            <div className="grid grid-cols-3 gap-2">
              <Card>
                <CardHeader className="p-3">
                  <CardTitle className="text-center text-lg">{comparisons}</CardTitle>
                </CardHeader>
                <CardContent className="p-3 pt-0">
                  <p className="text-xs text-center text-muted-foreground">Comparisons</p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="p-3">
                  <CardTitle className="text-center text-lg">{swaps}</CardTitle>
                </CardHeader>
                <CardContent className="p-3 pt-0">
                  <p className="text-xs text-center text-muted-foreground">Swaps</p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="p-3">
                  <CardTitle className="text-center text-lg">{elapsedTime.toFixed(2)}</CardTitle>
                </CardHeader>
                <CardContent className="p-3 pt-0">
                  <p className="text-xs text-center text-muted-foreground">Time (ms)</p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default AlgorithmInfo;
