
import React from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Slider } from '@/components/ui/slider';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import { SortingAlgorithm } from '@/utils/sortingAlgorithms';
import { generateRandomArray, generateNearlySortedArray, generateReversedArray } from '@/utils/arrayHelpers';
import { Pause, Play, RotateCcw, StepForward } from 'lucide-react';

interface ControlPanelProps {
  algorithms: SortingAlgorithm[];
  selectedAlgorithm: SortingAlgorithm;
  onAlgorithmChange: (algorithm: SortingAlgorithm) => void;
  arraySize: number;
  onArraySizeChange: (size: number) => void;
  delay: number;
  onDelayChange: (delay: number) => void;
  onGenerateArray: (array: number[]) => void;
  onSort: () => Promise<void>;
  onPause: () => void;
  onResume: () => void;
  onReset: () => void;
  onStepForward: () => Promise<void>;
  isSorting: boolean;
  isPaused: boolean;
}

const ControlPanel = ({
  algorithms,
  selectedAlgorithm,
  onAlgorithmChange,
  arraySize,
  onArraySizeChange,
  delay,
  onDelayChange,
  onGenerateArray,
  onSort,
  onPause,
  onResume,
  onReset,
  onStepForward,
  isSorting,
  isPaused,
}: ControlPanelProps) => {
  return (
    <Card className="w-full">
      <CardContent className="p-4 grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <div className="space-y-2">
          <Label htmlFor="algorithm">Algorithm</Label>
          <Select
            value={selectedAlgorithm.name}
            onValueChange={(value) => {
              const algorithm = algorithms.find((algo) => algo.name === value);
              if (algorithm) onAlgorithmChange(algorithm);
            }}
            disabled={isSorting}
          >
            <SelectTrigger id="algorithm">
              <SelectValue placeholder="Select Algorithm" />
            </SelectTrigger>
            <SelectContent>
              {algorithms.map((algorithm) => (
                <SelectItem key={algorithm.name} value={algorithm.name}>
                  {algorithm.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="arraySize">Array Size: {arraySize}</Label>
          <Slider
            id="arraySize"
            min={5}
            max={100}
            step={1}
            value={[arraySize]}
            onValueChange={(value) => onArraySizeChange(value[0])}
            disabled={isSorting}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="delay">Speed (Delay: {delay}ms)</Label>
          <Slider
            id="delay"
            min={1}
            max={500}
            step={1}
            value={[delay]}
            onValueChange={(value) => onDelayChange(value[0])}
          />
        </div>

        <div className="space-y-2 flex flex-col justify-end">
          <div className="grid grid-cols-2 gap-2">
            <Button onClick={() => onGenerateArray(generateRandomArray(arraySize))} disabled={isSorting}>
              Random
            </Button>
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button onClick={() => onGenerateArray(generateNearlySortedArray(arraySize))} disabled={isSorting}>
                    Nearly Sorted
                  </Button>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Generate a nearly sorted array with few elements out of place</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          </div>
          <div className="grid grid-cols-2 gap-2">
            <Button onClick={() => onGenerateArray(generateReversedArray(arraySize))} disabled={isSorting}>
              Reversed
            </Button>
            <Button variant="outline" onClick={onReset} disabled={!isSorting}>
              <RotateCcw className="mr-2 h-4 w-4" />
              Reset
            </Button>
          </div>
        </div>

        <div className="space-y-2 md:col-span-2 lg:col-span-4">
          <div className="flex flex-wrap gap-2 justify-center">
            {isSorting && !isPaused ? (
              <Button onClick={onPause} variant="outline">
                <Pause className="mr-2 h-4 w-4" />
                Pause
              </Button>
            ) : isSorting && isPaused ? (
              <Button onClick={onResume} variant="outline">
                <Play className="mr-2 h-4 w-4" />
                Resume
              </Button>
            ) : (
              <Button onClick={onSort} variant="default">
                <Play className="mr-2 h-4 w-4" />
                Sort
              </Button>
            )}
            
            {isSorting && isPaused && (
              <Button onClick={onStepForward} variant="outline">
                <StepForward className="mr-2 h-4 w-4" />
                Step Forward
              </Button>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default ControlPanel;
