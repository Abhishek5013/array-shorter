
import React, { useMemo } from 'react';
import { cn } from '@/lib/utils';
import { findMaxValue } from '@/utils/arrayHelpers';

interface ArrayVisualizerProps {
  array: number[];
  comparingIndices: number[];
  sortedIndices: number[];
  selectedIndex: number;
  containerHeight?: number;
}

const ArrayVisualizer = ({
  array,
  comparingIndices,
  sortedIndices,
  selectedIndex,
  containerHeight = 300,
}: ArrayVisualizerProps) => {
  const maxValue = useMemo(() => findMaxValue(array), [array]);
  
  return (
    <div 
      className="w-full border rounded-md flex items-end justify-center p-4 bg-card"
      style={{ height: `${containerHeight}px` }}
    >
      <div className="flex items-end justify-center w-full h-full gap-1">
        {array.map((value, index) => {
          const heightPercentage = (value / maxValue) * 100;
          const isComparing = comparingIndices.includes(index);
          const isSorted = sortedIndices.includes(index);
          const isSelected = selectedIndex === index;
          
          return (
            <div 
              key={index}
              className={cn(
                "array-bar",
                isComparing && "bg-[hsl(var(--array-comparing))] compare-animation",
                isSorted && "bg-[hsl(var(--array-sorted))]",
                isSelected && "bg-[hsl(var(--array-selected))]",
                !isComparing && !isSorted && !isSelected && "bg-[hsl(var(--array-default))]"
              )}
              style={{ 
                height: `${heightPercentage}%`,
                width: `${100 / array.length}%`,
                maxWidth: '40px',
                minWidth: '2px'
              }}
            />
          );
        })}
      </div>
    </div>
  );
};

export default ArrayVisualizer;
