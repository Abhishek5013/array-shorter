
import React, { useState, useRef, useEffect } from 'react';
import { toast } from '@/components/ui/use-toast';
import ArrayVisualizer from '@/components/ArrayVisualizer';
import ControlPanel from '@/components/ControlPanel';
import AlgorithmInfo from '@/components/AlgorithmInfo';
import { sortingAlgorithms } from '@/utils/sortingAlgorithms';
import { generateRandomArray } from '@/utils/arrayHelpers';

const Index = () => {
  // State for array and sorting
  const [array, setArray] = useState<number[]>([]);
  const [comparingIndices, setComparingIndices] = useState<number[]>([]);
  const [sortedIndices, setSortedIndices] = useState<number[]>([]);
  const [selectedIndex, setSelectedIndex] = useState<number>(-1);
  const [arraySize, setArraySize] = useState<number>(30);
  const [delay, setDelay] = useState<number>(50);
  const [selectedAlgorithm, setSelectedAlgorithm] = useState(sortingAlgorithms[0]);
  
  // State for algorithm stats and control
  const [isSorting, setIsSorting] = useState<boolean>(false);
  const [isPaused, setIsPaused] = useState<boolean>(false);
  const [comparisons, setComparisons] = useState<number>(0);
  const [swaps, setSwaps] = useState<number>(0);
  const [elapsedTime, setElapsedTime] = useState<number>(0);
  
  // Refs for sorting control
  const sortingRef = useRef<boolean>(false);
  const pauseRef = useRef<boolean>(false);
  const stepRef = useRef<boolean>(false);
  
  // Initialize array on mount and when size changes
  useEffect(() => {
    generateNewArray();
  }, [arraySize]);
  
  // Function to generate a new array
  const generateNewArray = (newArray?: number[]) => {
    if (isSorting) return;
    
    const array = newArray || generateRandomArray(arraySize);
    setArray(array);
    setComparingIndices([]);
    setSortedIndices([]);
    setSelectedIndex(-1);
    setComparisons(0);
    setSwaps(0);
    setElapsedTime(0);
  };
  
  // Function to handle algorithm change
  const handleAlgorithmChange = (algorithm: typeof selectedAlgorithm) => {
    if (isSorting) return;
    setSelectedAlgorithm(algorithm);
  };
  
  // Function to handle array size change
  const handleArraySizeChange = (size: number) => {
    setArraySize(size);
  };
  
  // Function to handle delay change
  const handleDelayChange = (newDelay: number) => {
    setDelay(newDelay);
  };
  
  // Function to start sorting
  const handleSort = async () => {
    if (isSorting || array.length === 0) return;
    
    setIsSorting(true);
    sortingRef.current = true;
    pauseRef.current = false;
    setIsPaused(false);
    setComparisons(0);
    setSwaps(0);
    
    const startTime = performance.now();
    
    try {
      // Create wrapper functions to track stats
      const updateArrayWithStats = (newArray: number[]) => {
        setArray(newArray);
        setSwaps((prev) => prev + 1);
      };
      
      const updateIndicesWithStats = (indices: number[]) => {
        setComparingIndices(indices);
        if (indices.length > 0) {
          setComparisons((prev) => prev + 1);
        }
      };
      
      // Start the sorting algorithm
      await selectedAlgorithm.sort(
        array,
        updateArrayWithStats,
        updateIndicesWithStats,
        delay
      );
      
      // Mark all as sorted when complete
      setSortedIndices(Array.from({ length: array.length }, (_, i) => i));
      setComparingIndices([]);
      
      toast({
        title: "Sorting Complete",
        description: `${selectedAlgorithm.name} finished in ${(performance.now() - startTime).toFixed(2)}ms`,
      });
    } catch (error) {
      console.error("Sorting error:", error);
      toast({
        title: "Sorting Error",
        description: "An error occurred while sorting",
        variant: "destructive",
      });
    } finally {
      setElapsedTime(performance.now() - startTime);
      sortingRef.current = false;
      setIsSorting(false);
    }
  };
  
  // Function to pause sorting
  const handlePause = () => {
    pauseRef.current = true;
    setIsPaused(true);
  };
  
  // Function to resume sorting
  const handleResume = () => {
    pauseRef.current = false;
    setIsPaused(false);
    
    // Force re-render to continue animation
    setArray([...array]);
  };
  
  // Function to reset sorting
  const handleReset = () => {
    sortingRef.current = false;
    pauseRef.current = false;
    setIsSorting(false);
    setIsPaused(false);
    setComparingIndices([]);
    setSortedIndices([]);
    setSelectedIndex(-1);
    setComparisons(0);
    setSwaps(0);
    setElapsedTime(0);
    
    // Regenerate the array
    generateNewArray();
  };
  
  // Function to step forward during pause
  const handleStepForward = async () => {
    if (!isSorting || !isPaused) return;
    
    // Set step mode to true, which will allow one iteration
    stepRef.current = true;
    pauseRef.current = false;
    
    // Force re-render to continue animation for one step
    setArray([...array]);
    
    // Wait a short time and then pause again
    await new Promise(resolve => setTimeout(resolve, delay * 2));
    pauseRef.current = true;
    stepRef.current = false;
  };
  
  return (
    <div className="container mx-auto p-4 max-w-6xl">
      <header className="text-center mb-8">
        <h1 className="text-3xl font-bold mb-2">Array Sorter Visualizer</h1>
        <p className="text-muted-foreground">
          Visualize and understand sorting algorithms through animation
        </p>
      </header>
      
      <div className="space-y-6">
        <ControlPanel
          algorithms={sortingAlgorithms}
          selectedAlgorithm={selectedAlgorithm}
          onAlgorithmChange={handleAlgorithmChange}
          arraySize={arraySize}
          onArraySizeChange={handleArraySizeChange}
          delay={delay}
          onDelayChange={handleDelayChange}
          onGenerateArray={generateNewArray}
          onSort={handleSort}
          onPause={handlePause}
          onResume={handleResume}
          onReset={handleReset}
          onStepForward={handleStepForward}
          isSorting={isSorting}
          isPaused={isPaused}
        />
        
        <ArrayVisualizer
          array={array}
          comparingIndices={comparingIndices}
          sortedIndices={sortedIndices}
          selectedIndex={selectedIndex}
          containerHeight={400}
        />
        
        <AlgorithmInfo
          algorithm={selectedAlgorithm}
          comparisons={comparisons}
          swaps={swaps}
          elapsedTime={elapsedTime}
        />
      </div>
    </div>
  );
};

export default Index;
